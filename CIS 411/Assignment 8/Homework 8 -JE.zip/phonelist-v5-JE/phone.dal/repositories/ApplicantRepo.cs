﻿using scholarship.dal;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace phone.dal.repositories
{
   public class ApplicantRepo : IRepository<Applicant>
    {
        private student8Entities _context = null;

        public ApplicantRepo()
        {
            _context = new student8Entities();
        }

        public Applicant getById(Applicant app2get)
        {
            return _context.Applicants.Find(app2get.APPLICANT_ID);
        }


        public Applicant[] getAll()
        {
            return _context.Applicants.ToArray();
        }

        public void add(Applicant applicant2add)
        {
            _context.Applicants.Add(applicant2add);
            _context.SaveChanges();
        }

        public void update(Applicant Applicant2update)
        {
            _context.Entry(Applicant2update).State = EntityState.Modified;
            _context.SaveChanges();
        }

        public void remove(Applicant applicant2remove)
        {
            _context.Applicants.Remove(applicant2remove);
            _context.SaveChanges();
        }

        public IQueryable<Applicant> query(System.Linq.Expressions.Expression<Func<Applicant, bool>> filter)
        {
            return _context.Applicants.Where(filter);
        }

    }

}