﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment7_JE.Models
{
    public class URLmodel
    {
        
        public string JSON_URL { get; set; }
    }
}