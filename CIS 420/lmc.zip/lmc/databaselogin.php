<?php 
// databaselogin.php
//
// Used to setup the database login variables

$db_hostname = '127.0.0.1';
//$db_hostname = 'lmcdbase.db.8860608.hostedresource.com';
$db_database = 'lmcdbase';
$db_username = 'lmcdbase';
$db_password = 'Pippin04';
?>