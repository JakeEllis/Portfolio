<?php 
// lmcclasses.php
// 
// This file is used to suck in all of the LMC related data classes.

require_once 'systemuser.php';


?>